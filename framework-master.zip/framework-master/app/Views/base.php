<!DOCTYPE html>
<html lang="en">

<head>
<?= $this->include('layout/head') ?>
</head>

<body>

    
    <?= $this->include('layout/header') ?>
    <?= $this->include('layout/welcome') ?>
    
    <?= $this->renderSection('content') ?>
    
    <?= $this->include('layout/footer') ?>

	<!-- Jquery dan Bootsrap JS -->
	<?= $this->include('layout/scripts') ?>
</body>

</html>