<?php

declare(strict_types=1);

namespace Laminas\Escaper\Exception;

interface ExceptionInterface
{
}
